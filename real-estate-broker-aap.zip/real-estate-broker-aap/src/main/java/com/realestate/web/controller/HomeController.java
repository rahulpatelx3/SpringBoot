package com.realestate.web.controller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.realestate.entity.User;
import com.realestate.controller.UserController;
import com.realestate.entity.Admin;
import com.realestate.entity.Cart;
import com.realestate.entity.Property;
import com.realestate.service.AdminService;
import com.realestate.service.CartService;
import com.realestate.service.PropertyService;
import com.realestate.service.UserService;

@Controller
public class HomeController {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	private boolean ulogin;
	private boolean alogin;
	private String uemail;
	private String aemail;
	public static String uploadDirectory = System.getProperty("user.home")+"\\Downloads\\real-estate-broker-aap13June3\\real-estate-broker-aap\\real-estate-broker-aap\\src\\main\\resources\\static\\images";
	@Autowired
	private UserService userService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private PropertyService propertyService;
	@Autowired
	private CartService cartService;
//	List<Property> AllProperty=new ArrayList<>();
	List<Cart> AllCart=new ArrayList<>();
	User u=new User();

	//Admin object variable to hold Which admin login
	Admin uniqueAdmin=new Admin();
	
	//User Object variable to hold which user login
	User uniqueUser=new User();
	
	//List to dynamically delete the property from user cart if admin delete that property;	
	List<Integer> dynamicDeleteCartID=new ArrayList<>();
		
	//dynamic prevent user form adding the same id property twice
	List<Integer> dyPrvntUsrfromAddSamePro=new ArrayList<>();
	
	@RequestMapping("/")
	public String index(Model model) {
		model.addAttribute("uemail", uemail);
		model.addAttribute("aemail", aemail);
		model.addAttribute("ulogin", ulogin);
		model.addAttribute("alogin", alogin);
		if(ulogin==false && alogin==false)
			model.addAttribute("login", true);
		return "index";
	}
	
	@RequestMapping("/service")
	public String service(Model model) {
		model.addAttribute("uemail", uemail);
		model.addAttribute("aemail", aemail);
		model.addAttribute("ulogin", ulogin);
		model.addAttribute("alogin", alogin);
		if(ulogin==false && alogin==false)
			model.addAttribute("login", true);
		return "service";
	}
	
	@RequestMapping("/help")
	public String help(Model model) {
		model.addAttribute("uemail", uemail);
		model.addAttribute("aemail", aemail);
		model.addAttribute("ulogin", ulogin);
		model.addAttribute("alogin", alogin);
		if(ulogin==false && alogin==false)
			model.addAttribute("login", true);
		return "help";
	}
	@RequestMapping("/login")
	public String loginPage(Model m) {
		if(u==null) {
			return "login";
		}
		if(this.ulogin==true) {
				
		uniqueUser=u;
		uniqueAdmin=null;
			List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
			
			System.out.println("user dashboard");
				m.addAttribute("data",AllPropertyinDatabse);
				m.addAttribute("uemail", uemail);
			return "userDashboard";
		}
		else if(this.alogin==true) {
			uniqueUser=null;
			List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
			
			System.out.println("admin dashboard");
				m.addAttribute("data",AllPropertyinDatabse);
				m.addAttribute("aemail", aemail);
		
		return "adminDashboard";
		}
		else {
			uniqueAdmin=null;
			uniqueUser=null;
			System.err.println("3");
			return "login";
		}
	}
	@PostMapping(path="/login")
	public String Login(@RequestParam("email") String email,@RequestParam("password") String password,Model m) {
		User u=userService.findUserByEmail(email);
		Admin admin=adminService.findAdminByEmail(email);
		
		
		if(u==null) {
			 
			 if(admin==null)
			{
				 //System.out.println("Admin Not Available");
				 LOGGER.info("Admin Not Available");
					m.addAttribute("emailHelp","Email does not exist Register First...");
				return "login";
			}
			
			if(admin.getAdminEmail().equals(email) && admin.getAdminPassword().equals(password))
			{
				aemail=admin.getAdminEmail();
				uniqueAdmin=admin;
				uniqueUser=null;
				//System.out.println("Admin Credentials Matched");
				m.addAttribute("aemail", aemail);
				LOGGER.info("Admin Credentials Matched");
				this.alogin=true;

				//static content start
				
					List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
					
					//System.out.println("1");
					m.addAttribute("data",AllPropertyinDatabse);
				
				return "adminDashboard";
				
			}
			else if(!(admin.getAdminPassword().equals(password))) {
				//System.out.println("Login Credentials not Matched");
				LOGGER.info("Login Credentials not Matched");
				m.addAttribute("passwordHelp","Admin Password is incorrect...");
				return "login";
			}
			
			
		}
		
		else if(u.getUserEmail().equals(email) && u.getUserPassword().equals(password))
		{
			uemail=u.getUserEmail();
			uniqueUser=u;
			uniqueAdmin=null;
			//System.out.println("User Credentials Matched");

			LOGGER.info("User login successful");
			this.ulogin=true;

			//static content start
			
				List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
				
				//System.out.println("2");
					m.addAttribute("data",AllPropertyinDatabse);
					m.addAttribute("uemail", uemail);
				return "userDashboard";
				
			
			//static content end
		}
		 
		else {
			//System.out.println("Login Credentials not Matched");
			LOGGER.info("Incorrect Pssword entered");
			m.addAttribute("passwordHelp","User Password does not match...");
			return "login";
		}
		return "login";
	}
	
	@GetMapping("/adminRegistration")
	public String adminRegistrationPage(Model m)
	{
		m.addAttribute("aemail", aemail);
		return "adminRegistration";
	}
	@PostMapping("/adminRegistration")
	public String adminRegistration(@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("city") String city,
			@RequestParam("state") String state,Model m) {
		Admin admin=new Admin();
		admin.setAdminName(name);
		admin.setAdminEmail(email);
		admin.setAdminPassword(password);
		admin.setAdminCity(city);
		admin.setAdminState(state);
		adminService.setAdmin(admin);
		m.addAttribute("admin", admin);
		List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
		m.addAttribute("data",AllPropertyinDatabse);
		m.addAttribute("aemail", aemail);
		System.out.println("Admin Registered Successfully");
		return "adminDashboard";
	}
	
	
	@RequestMapping("/logout")
	public String logout() {
		this.ulogin=false;
		this.alogin=false;
		//System.out.println("logout successfully");
		LOGGER.info("logout successfully");
		if(this.ulogin==true) {
			return "userDashboard";
		}
		else if(this.alogin==true) {
			return "adminDashboard";
		}
		else {
			return "login";
		}
	}
	
	@Transactional  //Transcational annotaion is used because this method is deleting the property from cart to sync the avaliable property with the admin
	@RequestMapping("/addToCart")                        
	public String showCart(Model m) {
		if(this.ulogin!=true) {
			return "login";
		}
		else	
		{	
			// loop for deleting the property which are deleted by the Admin
			if(dynamicDeleteCartID.size()>0)
			{
             
			for(int i=0;i<dynamicDeleteCartID.size();i++)
			{
				System.out.println("dynamic going to delete the property having id : "+dynamicDeleteCartID.get(i));
				
				cartService.deleteCartPropertyByID(dynamicDeleteCartID.get(i));
				System.out.println("deleted property having id : "+dynamicDeleteCartID.get(i)+" succuesfully");
			}
			}
			
			AllCart=cartService.getAllCartProperties();
			
			//System.out.println(AllCart);
			m.addAttribute("data",AllCart);
			m.addAttribute("uemail", uemail);
			return "userCart";		
		}
	}
	
	@PostMapping("/addToCartBtn")
	public String addToCart(@RequestParam("propertyId") int id,Model m) {
		if(this.ulogin!=true) {
			
			return "login";
		}
		
		else {
			System.out.println("Add Button");
			System.out.println(id);
			
			if(!(dyPrvntUsrfromAddSamePro.contains(id)))
			{
				dyPrvntUsrfromAddSamePro.add(id);
				Property p= propertyService.getProperty(id);
				
				Cart c=new Cart();
				c.setCartPropertyId(p.getPropertyId());
				c.setCartPropertyTitle(p.getPropertyTitle());
				c.setCartPropertyDescription(p.getPropertyDescription());
				c.setCartPropertyType(p.getPropertyType());
				c.setCartPropertyPrice(p.getPropertyPrice());
				c.setCartPropertyArea(p.getPropertyArea());
				c.setCartPropertyCity(p.getPropertyCity());
				c.setCartPropertyState(p.getPropertyState());
				c.setCartPath(p.getPath());
				cartService.setCartProperty(c);
			}
			
			if(this.ulogin==true) {
				
				List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
				
				System.out.println("User clicked on add property button having id : "+id);
					m.addAttribute("data",AllPropertyinDatabse);

				return "userDashboard";
			}
			else {
				return "login";
			}
		}
	}
		
	@PostMapping("/removeFromCart")
	public String removeFromCart(@RequestParam("propertyId") int id,Model m) {
		System.out.println("delete button pressed on remove from cart in userdashboard");

	     
		int deletidfromcart=cartService.getPropertyIdByCartId(id);
		cartService.deleteCartProperty(id);
		for(int i=0;i<dyPrvntUsrfromAddSamePro.size();i++)
		{
			if(dyPrvntUsrfromAddSamePro.get(i)==deletidfromcart)
			{					
				dyPrvntUsrfromAddSamePro.remove(i);
			}
		}
		if(this.ulogin==true) {
			
		 	List<Cart> AllCart=cartService.getAllCartProperties(); 
			m.addAttribute("data",AllCart);
			System.out.println("total property left in cart : "+AllCart.size());
			
			return "userCart";
		}
		else {
			
			return "login";
		}
	}
	
	
	@RequestMapping("/userDashboard")
	public String userDashboard() {
		return "userDashboard";
	}
	
	@RequestMapping("/registration")
	public String registerPage() {
		return "registration";
	}
	@PostMapping("/registration")
	public String Register(@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("city") String city,
			@RequestParam("state") String state,Model m) {
		User user=new User();
		user.setUserName(name);
		user.setUserEmail(email);
		user.setUserPassword(password);
		user.setUserCity(city);
		user.setUserState(state);
		userService.setUser(user);
		m.addAttribute("user", user);
		//System.out.println("Registered Successfully");
		LOGGER.info("Registered Successfully");
		return "login";
	}
	@RequestMapping("/forgetPassword")
	public String forgetPasswordPage() {
		return "forgetPassword";
	}
	@PostMapping("/forgetPassword")
	public String forgetPassword(@RequestParam("email") String email,
			@RequestParam("password") String password,Model m) {
		User u=userService.findUserByEmail(email);
		if(u==null) {
			//System.out.println("User Not Available");
			LOGGER.info("User Not Available");
			m.addAttribute("emailHelp","Email does not exist...");
			return "login";
		}
		else if(u.getUserEmail().equals(email)) {
			u.setUserPassword(password);
			//System.out.println("Password Reset Successfully");
			LOGGER.info("Password Reset Successfully");
			userService.setUser(u);
			m.addAttribute("user", u);
			return "login";
		}
		else {
			//System.out.println("Password Not Reseted Successfully");
			LOGGER.info("Password Not Reseted Successfully");
			m.addAttribute("passwordHelp","Password Reset Unsuccessfull...");
		return "forgetPassword";
		}
	}
	
	int PropertyEditId=0;
	
	@RequestMapping("/editProperty")
	public String editPropertyPage(@RequestParam("propertyId") int id,Model m) {
		Property pro=propertyService.getProperty(id);
		String title=pro.getPropertyTitle();
		String dis=pro.getPropertyDescription();
		int pri=pro.getPropertyPrice();
		String type=pro.getPropertyType();
		String area=pro.getPropertyArea();
		String city=pro.getPropertyCity();
		String state=pro.getPropertyState();
		String path=pro.getPath();
		m.addAttribute("title",title);
		m.addAttribute("dis",dis);
		m.addAttribute("pri",pri);
		m.addAttribute("type",type);
		m.addAttribute("area",area);
		m.addAttribute("city",city);
		m.addAttribute("state",state);
		m.addAttribute("path",path);
		m.addAttribute("aemail", aemail);
		System.out.println("property selected for edit have id : "+id);
		PropertyEditId=id;
		return "editProperty";
	}
	@PostMapping("/editProperty")
	public String editProperty(Model m,@RequestParam("files") MultipartFile file,
			@RequestParam("propertyPrice") int propertyPrice,
			  @RequestParam("propertyType") String propertyType,
			  @RequestParam("propertyArea") String propertyArea,
			  @RequestParam("propertyCity") String propertyCity,
			  @RequestParam("propertyState") String propertyState,
			  @RequestParam("propertyTitle") String propertyTitle,
			  @RequestParam("propertyDescription") String propertyDescription) {
		
		
		String ImagePath="/images/"+file.getOriginalFilename();
		System.out.println("updated image name= "+ImagePath);
		System.out.println("edit button");
		Path fileNameAndPath = Paths.get(uploadDirectory, file.getOriginalFilename());
		  try {
			Files.write(fileNameAndPath, file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
			Property pro=propertyService.getProperty(PropertyEditId);
		  System.out.println("before update");
		  System.out.println(pro);
		  pro.setPath(ImagePath);
		pro.setPropertyArea(propertyArea);
		pro.setPropertyCity(propertyCity);
		pro.setPropertyDescription(propertyDescription);
		pro.setPropertyPrice(propertyPrice);
		pro.setPropertyState(propertyState);
		pro.setPropertyTitle(propertyTitle);
		pro.setPropertyType(propertyType);
		
		System.out.println("after update property");
		System.out.println(pro);
		
		
		propertyService.saveImage(pro);
		 System.out.println("Property Updated... id = "+PropertyEditId);
		 if(this.alogin==true) {
			 List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
				m.addAttribute("data",AllPropertyinDatabse);
				System.out.println("if block");
				
				return "adminDashboard";
		 }
		 return "login";
	}
	@PostMapping("/removeProperty")
	public String removeProperty(@RequestParam("propertyId") int id,Model m) {
		System.out.println("property delete button");
		System.out.println(id);
		
		propertyService.deleteProperty(id);
		if(this.alogin==true) {
			
				//AllCart=cartService.getAllCartProperties(); 

			List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
			m.addAttribute("data",AllPropertyinDatabse);
			m.addAttribute("aemail", aemail);
			System.out.println("if block");
			
			return "adminDashboard";
		}
		else {
			System.out.println("else block");
			return "login";
		}
	}	

	@RequestMapping("/filter")
	public String getFilter() {
		return "login";
	}
	@PostMapping("/filter")
	public String postFilter(@RequestParam("filterBox") String filter,Model m) {
		System.out.println(filter);
		
		
		if(filter.equals("city")) {
			
			if(uniqueAdmin!=null)
			{
				System.out.println(uniqueAdmin);
				String city=uniqueAdmin.getAdminCity();
				List<Property> AllPropertyinDatabse=propertyService.GetAllPropertyByCity(city);
				m.addAttribute("data",AllPropertyinDatabse);
			}
			
			else
			{
				System.out.println(uniqueUser);
				String city=uniqueUser.getUserCity();
				List<Property> AllPropertyinDatabse=propertyService.GetAllPropertyByCity(city);
				m.addAttribute("data",AllPropertyinDatabse);
			}
		}
		else if(filter.equals("state")) 
		{
			if(uniqueAdmin!=null)
			{
				System.out.println(uniqueAdmin);
				String state=uniqueAdmin.getAdminState();
				List<Property> AllPropertyinDatabse=propertyService.GetAllPropertyByState(state);
				m.addAttribute("data",AllPropertyinDatabse);
			}
			
			else 
			{   System.out.println(uniqueUser);
				String state=uniqueUser.getUserState();
				List<Property> AllPropertyinDatabse=propertyService.GetAllPropertyByState(state);
				m.addAttribute("data",AllPropertyinDatabse);
			}
		}
		else {

			//filter by all (No- Chnage)
			
			List<Property> AllPropertyinDatabse=propertyService.getAllProperties();
			m.addAttribute("data",AllPropertyinDatabse);
		}
		if(this.alogin==true) {
			return "adminDashboard";
		}
		else if(this.ulogin==true) {
			return "userDashboard";
		}
		else {
			return "login";
		}
	}
	
	@RequestMapping("/buy")
	public String buyBtn() {
		return "payment";
	}
	@PostMapping("/buy")
	public String buy() {
		return "payment";
	}

}

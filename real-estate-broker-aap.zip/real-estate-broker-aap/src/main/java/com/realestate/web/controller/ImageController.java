package com.realestate.web.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.realestate.entity.Property;
import com.realestate.service.PropertyService;

@Controller
public class ImageController {
	public static String uploadDirectory = System.getProperty("user.home")+"\\Downloads\\real-estate-broker-aap13June3\\real-estate-broker-aap\\real-estate-broker-aap\\src\\main\\resources\\static\\images";
	
	@Autowired
	private PropertyService propertyService;
	


	@RequestMapping("/userAddNew")
	public String view()
	{
		return "userAddNew";
	}
	
	@PostMapping("/userAddNew")
	  public String upload(Model model,@RequestParam("files") MultipartFile file,@RequestParam("propertyPrice") int propertyPrice,
			  @RequestParam("propertyType") String propertyType,@RequestParam("propertyArea") String propertyArea,
			  @RequestParam("propertyCity") String propertyCity,
			  @RequestParam("propertyState") String propertyState,
			  @RequestParam("propertyTitle") String propertyTitle,
			  @RequestParam("propertyDescription") String propertyDescription) {
		
			  Path fileNameAndPath = Paths.get(uploadDirectory, file.getOriginalFilename());
			  try {
				Files.write(fileNameAndPath, file.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			  
			  String ImagePath="/images/"+file.getOriginalFilename();
				Property pro=new Property(); 
		
			  
			 pro.setPropertyPrice(propertyPrice);
			 pro.setPropertyType(propertyType);
			 pro.setPropertyArea(propertyArea);
			 pro.setPropertyCity(propertyCity);
			 pro.setPropertyTitle(propertyTitle);
			 pro.setPropertyDescription(propertyDescription);
			 pro.setPropertyState(propertyState);
			 pro.setPath(ImagePath);
			 
			  
			 propertyService.saveImage(pro);
			  
			  System.out.println(fileNameAndPath);
			  model.addAttribute("msg","Successfully uploaded "+ file.getOriginalFilename().toString());
		  return "userAddNew";
	}

}

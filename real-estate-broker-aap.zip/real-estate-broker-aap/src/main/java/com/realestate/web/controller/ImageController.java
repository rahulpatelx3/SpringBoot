package com.realestate.web.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.realestate.entity.Property;
import com.realestate.service.PropertyService;

@Controller
public class ImageController {
	public static String uploadDirectory = System.getProperty("user.dir")+"/uploads";
	
	@Autowired
	private PropertyService propertyService;
	
	Property pro=new Property();

	@RequestMapping("/userAddNew")
	public String view()
	{
		return "userAddNew";
	}
	
	@PostMapping("/userAddNew")
	  public String upload(Model model,@RequestParam("files") MultipartFile file,@RequestParam("propertyPrice") int propertyPrice,
			  @RequestParam("propertyType") String propertyType,@RequestParam("propertyArea") String propertyArea,
			  @RequestParam("propertyCity") String propertyCity,
			  @RequestParam("propertyState") String propertyState,
			  @RequestParam("propertyCity") String propertyTitle,
			  @RequestParam("propertyState") String propertyDescription) {
		
			  Path fileNameAndPath = Paths.get(uploadDirectory, file.getOriginalFilename());
			  try {
				Files.write(fileNameAndPath, file.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			  
			 pro.setPropertyPrice(propertyPrice);
			 pro.setPropertyType(propertyType);
			 pro.setPropertyArea(propertyArea);
			 pro.setPropertyCity(propertyCity);
			 pro.setPropertyTitle(propertyTitle);
			 pro.setPropertyDescription(propertyDescription);
			 pro.setPropertyState(propertyState);
			 pro.setPath(uploadDirectory);
			 
			  
			 propertyService.saveImage(pro);
			  
			  System.out.println(fileNameAndPath);
			  model.addAttribute("msg","Successfully uploaded "+ file.getOriginalFilename().toString());
		  return "afterImageUpload";
	}

}

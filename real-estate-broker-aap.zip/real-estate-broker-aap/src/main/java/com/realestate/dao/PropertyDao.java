package com.realestate.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.realestate.entity.Property;
@Repository
public interface PropertyDao extends JpaRepository<Property, Integer> {
	
	
	
	List<Property> findByPropertyCityContainingIgnoreCase(String city);
	
	List<Property> findByPropertyStateContainingIgnoreCase(String state);

}

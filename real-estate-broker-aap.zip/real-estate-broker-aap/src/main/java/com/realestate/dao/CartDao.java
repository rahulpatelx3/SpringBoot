package com.realestate.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.realestate.entity.Cart;

@Repository
public interface CartDao extends JpaRepository<Cart, Integer> {
	
void deleteBycartPropertyId(int id);
	
	Cart findBycartPropertyPrice(int price);

	@Query(value = "select cart_property_id from cart where cart_id=?1", nativeQuery = true)
	int findBycartPropertyId(int id);

}

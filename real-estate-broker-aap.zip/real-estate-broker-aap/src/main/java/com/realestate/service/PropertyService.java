package com.realestate.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.realestate.dao.PropertyDao;
import com.realestate.entity.Property;

@Service
public class PropertyService {
	@Autowired
	private PropertyDao propertyDao;
	
	public Property getProperty(int id) {
		Property property=null;
		try {
			Optional<Property> optional=this.propertyDao.findById(id);
			property=optional.get();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return property;
	}
	
	public List<Property> getAllProperties(){
		return this.propertyDao.findAll();
	}
	
	public Property setProperty(Property u) {
		return this.propertyDao.save(u);
	}
	
	public void deleteProperty(int id){
		this.propertyDao.deleteById(id);
	}
	
	public void saveImage(Property pro)
	{
		propertyDao.save(pro);
	}
	
	public List<Property> GetAllPropertyByCity(String city)
	{
		return propertyDao.getAllByCity(city);
	}
	
	public List<Property> GetAllPropertyByState(String state)
	{
		return propertyDao.getAllByState(state);
	}
}

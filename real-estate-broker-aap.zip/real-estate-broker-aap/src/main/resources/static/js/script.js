let preLoader = document.getElementById('loading');

function myFunction() {
    preLoader.style.display = 'none';
}

let filter = document.querySelector('#filter');

let data = localStorage.getItem('data');
sendData(data);

filter.addEventListener('change', (e) => {
    localStorage.setItem('data', e.target.value);
    sendData(e.target.value);
});

function sendData(myVariable) {
    document.querySelector('#filterBox').value = myVariable;
}

window.addEventListener('storage', (e) => {
    if (e.key === 'data') {
        sendData(e.newValue);
        filter.value = e.newValue;
    }
});


$(function() {
    $('[data-toggle="tooltip"]').tooltip()
})